A zip, holding a tar.gz, holding a 7z, holding a zip. Open them in turn.
