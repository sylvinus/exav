Example archive
===============

This archive holds a few files of the exav demo. It is in the public domain
(CC0-1.0). Look at the folders: docs, data, images, src, an empty one, and a
folder with accented and Japanese names.
